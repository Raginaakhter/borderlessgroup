module.exports=[52826,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_prohibited-items_page_actions_0etpt71i4tpky.js.map