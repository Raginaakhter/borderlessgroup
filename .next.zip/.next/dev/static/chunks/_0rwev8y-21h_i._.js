(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0kr39vyzs3cyl._.css","static/chunks/node_modules_1g0s5vcuhnqc0._.js","static/chunks/src_components_19biok9c-u_j_._.js","static/chunks/_1w46ckgo97w4c._.js"],
    source: "entry"
});
