(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0kr39vyzs3cyl._.css","static/chunks/node_modules_1g0s5vcuhnqc0._.js","static/chunks/src_components_19biok9c-u_j_._.js","static/chunks/src_components_0rzwa8yf8uehc._.js","static/chunks/1daa_framer-motion_dist_es_utils_reduced-motion_use-reduced-motion_mjs_05jjzqm5hk0cz._.js"],
    source: "entry"
});
